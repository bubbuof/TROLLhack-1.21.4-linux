package ru.zenith.mixins;

import net.minecraft.client.input.Input;
import org.spongepowered.asm.mixin.Mixin;
import ru.zenith.common.QuickImports;

@Mixin(Input.class)
public class InputMixin implements QuickImports {

}
