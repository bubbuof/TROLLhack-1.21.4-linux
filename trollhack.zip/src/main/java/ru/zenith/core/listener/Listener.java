package ru.zenith.core.listener;

import ru.zenith.common.QuickLogger;

public interface Listener extends QuickLogger {}
