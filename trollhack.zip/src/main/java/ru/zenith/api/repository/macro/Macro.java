package ru.zenith.api.repository.macro;

public record Macro(String name, String message, int key) {}
