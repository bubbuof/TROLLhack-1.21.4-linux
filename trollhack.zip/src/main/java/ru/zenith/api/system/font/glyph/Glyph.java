package ru.zenith.api.system.font.glyph;

public record Glyph(int u, int v, int width, int height, char value, GlyphMap owner) {
}
