package ru.zenith.api.system.animation;

public enum Direction {
    FORWARDS,
    BACKWARDS
}
