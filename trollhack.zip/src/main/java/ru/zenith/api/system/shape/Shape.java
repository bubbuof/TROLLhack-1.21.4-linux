package ru.zenith.api.system.shape;

public interface Shape {
    void render(ShapeProperties shapeProperties);
}
