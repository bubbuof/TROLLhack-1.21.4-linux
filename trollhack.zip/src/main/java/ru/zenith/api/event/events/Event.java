package ru.zenith.api.event.events;

public interface Event {

}
