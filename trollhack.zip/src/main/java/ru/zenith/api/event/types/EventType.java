package ru.zenith.api.event.types;

public class EventType {

    public static final byte
            START = -1,
            PRE = 0,
            ON = 1,
            POST = 2,
            SEND = 3,
            RECIEVE = 4;

}
