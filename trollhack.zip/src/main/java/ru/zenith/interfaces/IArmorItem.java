package ru.zenith.interfaces;

import net.minecraft.item.equipment.ArmorMaterial;
import net.minecraft.item.equipment.EquipmentType;

public interface IArmorItem {
    ArmorMaterial zov_pidarok$getMaterial();
    EquipmentType zov_pidarok$getType();
}
