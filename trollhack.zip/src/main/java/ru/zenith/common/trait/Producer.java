package ru.zenith.common.trait;

public interface Producer<T> {
    T create();
}