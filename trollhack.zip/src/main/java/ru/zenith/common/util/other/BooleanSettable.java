package ru.zenith.common.util.other;

import lombok.Getter;
import lombok.Setter;

@Getter
public class BooleanSettable {
    @Setter
    private boolean value;

    public BooleanSettable() {}
}
