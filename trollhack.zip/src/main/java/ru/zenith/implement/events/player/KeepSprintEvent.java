package ru.zenith.implement.events.player;

import ru.zenith.api.event.events.Event;

public class KeepSprintEvent implements Event {
}
