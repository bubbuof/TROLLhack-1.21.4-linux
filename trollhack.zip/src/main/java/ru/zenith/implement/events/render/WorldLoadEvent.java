package ru.zenith.implement.events.render;

import ru.zenith.api.event.events.Event;

public class WorldLoadEvent implements Event {
}
