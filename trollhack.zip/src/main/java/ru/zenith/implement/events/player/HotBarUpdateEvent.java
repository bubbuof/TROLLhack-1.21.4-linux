package ru.zenith.implement.events.player;

import ru.zenith.api.event.events.callables.EventCancellable;

public class HotBarUpdateEvent extends EventCancellable {

}
