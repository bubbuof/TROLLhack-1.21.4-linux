package ru.kotopushka.compiler.sdk.enums;

public enum VMProtectType {
    VIRTUALIZATION,
    MUTATION,
    ULTRA
}